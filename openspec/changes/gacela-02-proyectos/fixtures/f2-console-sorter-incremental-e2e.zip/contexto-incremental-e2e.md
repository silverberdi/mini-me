# Ampliación sintética de prueba — consola para ordenar diez números

**ESTE ARCHIVO ES UNA FUENTE SINTÉTICA EXCLUSIVA DEL E2E F2.** No expresa nuevas decisiones reales del propietario, ni debe incorporarse a ningún proyecto distinto al repositorio desechable `silverberdi/mini-me-f2-e2e-20261023`.

La fuente inicial estableció: programa de consola que recibe diez números y los presenta ordenados de menor a mayor. Para comprobar que el flujo incremental añade información nueva sin alterar el contexto aprobado, esta fuente de ensayo introduce **únicamente para el proyecto desechable** las siguientes especificaciones ficticias adicionales:

- Los diez números de entrada son enteros y se suministran en una sola línea separados por espacios.
- Pueden incluir números negativos y valores repetidos.
- El resultado mantiene los valores repetidos y se presenta separado por espacios.

No especifica lenguaje de programación, almacenamiento ni política de errores. No solicita crear backlog, issues, propuestas OpenSpec ni código de aplicación.
