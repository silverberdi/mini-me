# Observación contradictoria sintética — NO es un reemplazo

**ESTE ARCHIVO ES UNA FUENTE SINTÉTICA EXCLUSIVA DEL E2E F2.** Se utiliza solamente para demostrar que una nueva fuente contradictoria se conserva sin sustituir silenciosamente el contexto previamente aprobado.

Una observación de prueba propone mostrar los diez números en orden **descendente**. Esta propuesta contradice el orden **ascendente** definido en el documento Greenfield original.

**No se autoriza ningún reemplazo** de la regla previamente aprobada. La contradicción debe registrarse de forma documental, citando tanto el material Greenfield original como esta fuente de prueba, sin asumir un nuevo requisito operativo.
